#ifndef COMMON_H
#define COMMON_H

#define MAGIC_STRING "#*"

#endif

